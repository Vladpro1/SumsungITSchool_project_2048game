package com.example.first_math2048_game;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends Activity implements View.OnClickListener{
    public TextView tvScore;//Scored
    public TextView tvBestScore;//Highest score
    public int score = 0;
    private int bestScores;//Highest score in history
    private Button bt;

    private static MainActivity mainActivity = null;
    public MainActivity(){
        mainActivity = this;
    }

    public static MainActivity getMainActivity() {
        return mainActivity;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inital();

    }

    @SuppressLint("SetTextI18n")
    public void inital() {
        tvBestScore = (TextView) findViewById(R.id.maxSorce);
        tvScore = (TextView) findViewById(R.id.tvSorce);
        bt = (Button)findViewById(R.id.bt_cx);
        bt.setOnClickListener(this);
        Safe_score bastScore = new Safe_score(this);
        bestScores = bastScore.getSafe_score();
        tvBestScore.setText(bestScores+"");
    }

    @Override
    public void onClick(View v) {
        GameView.getGameView().startGame();
    }

    public void clearScore(){
        score = 0;
        showScore();
    }
    public void showScore(){
        tvScore.setText(score+"");
    }
    public void addScore(int s){
        score+=s;
        showScore();
        if (score > bestScores){
            bestScores = score;
            Safe_score bs = new Safe_score(this);
            bs.setSafe_score(bestScores);
            tvBestScore.setText(bestScores+"");
        }
    }


    private long exitTime = 0;

    @SuppressLint("WrongConstant")
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK
                && event.getAction() == KeyEvent.ACTION_DOWN) {
            if ((System.currentTimeMillis() - exitTime) > 2000) {
                Toast.makeText(this, "Нажмите ещё раз, чтобы выйти",1000).show();
                exitTime = System.currentTimeMillis();
            } else {
                finish();
                System.exit(0);
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

}
