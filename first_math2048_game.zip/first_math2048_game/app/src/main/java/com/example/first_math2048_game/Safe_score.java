package com.example.first_math2048_game;

import android.content.Context;
import android.content.SharedPreferences;

public class Safe_score {
    private SharedPreferences s;
    Safe_score(Context context){
        s = context.getSharedPreferences("bestscore",context.MODE_PRIVATE);

    }

    public int getSafe_score(){
        int bestscore = s.getInt("bestscore",0);
        return bestscore;
    }
    public void setSafe_score(int bestScore){
        SharedPreferences.Editor editor = s.edit();
        editor.putInt("bestscore",bestScore);
        editor.commit();
    }
}